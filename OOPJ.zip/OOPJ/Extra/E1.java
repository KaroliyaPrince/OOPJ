class StringDemo {

    void showStringMethods() {

        String str = "Hello";

        System.out.println("\n String Methods \n");
        System.out.println("Original: " + str);
        System.out.println("Length: " + str.length());
        System.out.println("CharAt(1): " + str.charAt(1));
        System.out.println("Uppercase: " + str.toUpperCase());
        System.out.println("Lowercase: " + str.toLowerCase());
        System.out.println("Substring(1,4): " + str.substring(1,4));
        System.out.println("Replace l with x: " + str.replace('l','x'));
        System.out.println("Concat: " + str.concat(" Java"));
    }
}


class StringBufferDemo {

    void showStringBufferMethods() {

        StringBuffer sb = new StringBuffer("Java");

        System.out.println("\n StringBuffer Methods \n");
        System.out.println("Original: " + sb);

        sb.append(" Programming");
        System.out.println("After Append: " + sb);

        sb.insert(4, " Language");
        System.out.println("After Insert: " + sb);

        sb.replace(0,4,"Core");
        System.out.println("After Replace: " + sb);

        sb.delete(0,5);
        System.out.println("After Delete: " + sb);

        sb.reverse();
        System.out.println("After Reverse: " + sb);

        System.out.println("Capacity: " + sb.capacity());
    }
}


class StringBuilderDemo {

    void showStringBuilderMethods() {

        StringBuilder sb = new StringBuilder("OOPJ");

        System.out.println("\n StringBuilder Methods \n");
        System.out.println("Original: " + sb);

        sb.append(" Lab");
        System.out.println("After Append: " + sb);

        sb.insert(4, " Practical");
        System.out.println("After Insert: " + sb);

        sb.delete(4,14);
        System.out.println("After Delete: " + sb);

        sb.reverse();
        System.out.println("After Reverse: " + sb);

        System.out.println("Length: " + sb.length());
    }
}


public class E1 {

    public static void main(String[] args) {

        StringDemo s1 = new StringDemo();
        s1.showStringMethods();

        StringBufferDemo s2 = new StringBufferDemo();
        s2.showStringBufferMethods();

        StringBuilderDemo s3 = new StringBuilderDemo();
        s3.showStringBuilderMethods();
    }
}