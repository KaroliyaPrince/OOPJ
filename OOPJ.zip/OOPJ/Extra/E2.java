import java.util.Scanner;

public class E2 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a String: ");
        String input = sc.nextLine();

        String result = "";

        for(int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);

            if(i % 2 == 0)
                result += Character.toUpperCase(ch);
            else
                result += Character.toLowerCase(ch);
        }

        System.out.println("Output: " + result);
    }
}