public class E3 {
    public static void main(String[] args) {

        System.out.println("Absolute: " + Math.abs(-10));
        System.out.println("Power: " + Math.pow(2,3));
        System.out.println("Square Root: " + Math.sqrt(25));
        System.out.println("Max: " + Math.max(10,20));
        System.out.println("Min: " + Math.min(10,20));
        System.out.println("Ceil: " + Math.ceil(5.3));
        System.out.println("Floor: " + Math.floor(5.7));
        System.out.println("Round: " + Math.round(5.6));
        System.out.println("Random: " + Math.random());
        System.out.println("PI Value: " + Math.PI);
    }
}