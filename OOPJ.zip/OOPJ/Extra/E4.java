public class E4 {
    public static void main(String[] args) {

        int random = (int)(Math.random() * 100) + 1;
        System.out.println("Random Number (1-100): " + random);
    }
}