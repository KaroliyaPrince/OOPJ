public class E5 {

    static int count = 0;   

    static {                
        System.out.println("Static Block Executed");
    }

    static void display() { 
        System.out.println("Static Method Called");
    }

    static class Inner {    
        void show() {
            System.out.println("Static Inner Class Method");
        }
    }

    E5() {
        count++;
    }

    public static void main(String[] args) {

        E5 obj1 = new E5();
        E5 obj2 = new E5();

        System.out.println("Count: " + count);

        display();

        Inner in = new Inner();
        in.show();
    }
}

// class A {
//     static {
//         System.out.println("Static block of A");
//     }
// }

// public class MainClass {
//     public static void main(String[] args) {
//         A obj = new A();   // Using class A
//         System.out.println("Main method");
//     }
// }