import java.util.Scanner;

public class ButterflyPattern {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter N");
        int n=sc.nextInt();
        for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++){
                System.out.print("*");
            }
            for(int k=0;k<2*(n-i-1)-1;k++){
                System.out.print(" ");
            }
            for(int l=0;l<=i;l++){
                if(l==n-1){
                    break;
                }
                System.out.print("*");
            }
            System.out.println();
        }
        for(int i=(n-2);i>=0;i--){
			for(int j=0;j<=i;j++){
                System.out.print("*");
            }
            for(int k=0;k<2*(n-i-1)-1;k++){
				System.out.print(" ");
			}
			for(int l=0;l<=i;l++){
				System.out.print("*");
			}
			System.out.println();
		}
    }
}
