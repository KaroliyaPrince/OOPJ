public class L1_A_4II {
    public static void main(String[] args) {
        int n=5;
        for(int i=0;i<5;i++){
            for(int j=0;j<n-i;j++){
                System.out.print(" ");
            }
            for(int j=0;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
