public class L1_B_5IV {
    public static void main(String[] args) {
        int n=5;
        for(int i=(n-1);i>=0;i--){
			for(int j=0;j<n-i;j++){
				System.out.print(" ");
			}
			for(int j=0;j<=i;j++){
                if(i%2==0)
				    System.out.print("* ");
                else
                    System.out.print("# ");
            }
			System.out.println();
		}
    }
}
