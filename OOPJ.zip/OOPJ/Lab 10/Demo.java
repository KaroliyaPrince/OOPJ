class A{

}

public class Demo {
    public static void main(String[] args) {
        A obj1=new A();
        A obj2=new A();
        System.out.println(obj1.toString());
        System.out.println(obj2.toString());
    }
}
