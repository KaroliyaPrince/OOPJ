interface Car {
    void moveForward();
    void moveBackward();
    void moveLeft();
    void moveRight();
    void applyBreak();
}

class Swift implements Car {
    public void moveForward() {
        System.out.println("Swift moving forward");
    }

    public void moveBackward() {
        System.out.println("Swift moving backward");
    }

    public void moveLeft() {
        System.out.println("Swift turning left");
    }

    public void moveRight() {
        System.out.println("Swift turning right");
    }

    public void applyBreak() {
        System.out.println("Swift brake applied");
    }
}

class Thar implements Car {
    public void moveForward() {
        System.out.println("Thar moving forward");
    }

    public void moveBackward() {
        System.out.println("Thar moving backward");
    }

    public void moveLeft() {
        System.out.println("Thar turning left");
    }

    public void moveRight() {
        System.out.println("Thar turning right");
    }

    public void applyBreak() {
        System.out.println("Thar brake applied");
    }
}

public class L11_B_4 {
    public static void main(String[] args) {
        Car car1 = new Swift();
        car1.moveForward();
        car1.moveLeft();
        car1.applyBreak();

        Car car2 = new Thar();
        car2.moveForward();
        car2.moveRight();
        car2.applyBreak();
    }
}
