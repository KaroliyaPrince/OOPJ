interface Playable{
    void play();
}
class Football implements Playable{
    public void play(){
        System.out.println("Football is Running");
    }
}
class Volleyball implements Playable{
    public void play(){
        System.out.println("Volleyball is Running");
    }
}
class Basketball implements Playable{
    public void play(){
        System.out.println("Basketball is Running");
    }
}
public class L11_C_5{
    public static void main(String[] args) {
        Playable f=new Football();
        Playable v=new Volleyball();
        Playable b=new Basketball();

        f.play();
        v.play();
        b.play();
    }
}