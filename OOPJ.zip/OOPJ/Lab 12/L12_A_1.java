public class L12_A_1 {
    public static void main(String[] args) {
        try{
            int a=10;
            int b=0;
            int result=a/b;
            System.out.println("Result: " + result);
        }catch(ArithmeticException e){
            System.out.println("Arithmetic Exception caught: " + e);
        }
        try{
            int[] arr = {1, 2, 3};
           System.out.println(arr[5]);
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Array Index Out Of Bounds Exception caught: " + e);
        }
        System.out.println("Byee");
    }
}
