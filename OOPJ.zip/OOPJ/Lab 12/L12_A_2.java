class Account {
    double balance = 5000;
    double minBalance = 1000;

    void withdraw(double amount) throws Exception {
        if (balance - amount < minBalance) {
            throw new Exception("Insufficient funds! Minimum balance must be maintained.");
        }
        balance = balance - amount;
        System.out.println("Withdrawal Successful");
        System.out.println("Remaining Balance: " + balance);
    }
}

public class L12_A_2 {
    public static void main(String[] args) {

        Account acc = new Account();

        try {
            acc.withdraw(4500);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
