
import java.util.Scanner;

public class L12_A_3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        try {
            System.out.println("Enter Age");
            int age = sc.nextInt();

            if (age < 18) {
                throw new Exception("Age is less than 18. Not eligible.");
            }

            System.out.println("Age is valid. Eligible.");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
