
import java.util.Scanner;

public class L12_B_4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        try {
            System.out.println("Enter Number 1");
            int num1=sc.nextInt();
            System.out.println("Enter Number 2");
            int num2=sc.nextInt();

            int result = num1 / num2;
            System.out.println("Result: " + result);

        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter valid integers.");

        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Please provide two numbers.");
        }
    }
}