
import java.util.Scanner;

public class L12_C_5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        try {
            System.out.println("Enter Number");
            int num=sc.nextInt();

            if (num < 10 || num > 50) {
                throw new Exception("Number is out of range.");
            }

            System.out.println("Square of number: " + (num * num));

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
