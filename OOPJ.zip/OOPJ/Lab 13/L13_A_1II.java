class MyRunnable2 implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Runnable interface: " + i);
        }
    }
}

public class L13_A_1II {
    public static void main(String[] args) {

        MyRunnable2 r = new MyRunnable2();
        Thread t = new Thread(r);
        t.start();
    }
}
