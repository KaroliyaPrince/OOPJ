import java.util.Random;

class NumberGenerator implements Runnable {
    public void run() {
        Random r = new Random();

        try {
            while (true) {
                int num = r.nextInt(10);
                System.out.println("Generated Number: " + num);

                if (num % 2 == 0) {
                    Thread t = new Thread(new Square(num));
                    t.start();
                } else {
                    Thread t = new Thread(new Cube(num));
                    t.start();
                }

                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
}

class Square implements Runnable {
    int num;

    Square(int num) {
        this.num = num;
    }

    public void run() {
        System.out.println("Square of " + num + " = " + (num * num));
    }
}

class Cube implements Runnable {
    int num;

    Cube(int num) {
        this.num = num;
    }

    public void run() {
        System.out.println("Cube of " + num + " = " + (num * num * num));
    }
}

public class L13_B_5 {
    public static void main(String[] args) {

        Thread t = new Thread(new NumberGenerator());
        t.start();
    }
}
