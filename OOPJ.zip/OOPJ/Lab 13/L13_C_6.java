import java.util.Scanner;

class RowSum extends Thread {
    int row[];
    int rowNo;

    RowSum(int row[], int rowNo) {
        this.row = row;
        this.rowNo = rowNo;
    }

    public void run() {
        int sum = 0;
        for (int i = 0; i < row.length; i++) {
            sum += row[i];
        }
        System.out.println("Sum of row " + rowNo + " = " + sum);
    }
}

public class L13_C_6 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of rows (m): ");
        int m = sc.nextInt();
        System.out.print("Enter number of columns (n): ");
        int n = sc.nextInt();

        int A[][] = new int[m][n];

        System.out.println("Enter matrix elements:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                A[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < m; i++) {
            RowSum t = new RowSum(A[i], i);
            t.start();
        }
    }
}
