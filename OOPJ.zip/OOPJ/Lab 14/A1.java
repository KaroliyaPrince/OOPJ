import java.io.File;
import java.io.FileInputStream;

public class A1 {
    public static void main(String[] args) throws Exception{


        File f1 = new File("demo.txt");
        FileInputStream in = new FileInputStream(f1);

        int numberOfLine=0;
        int numberOfWord = 0;
        int numberOfchar = 0;
        int ch;

        while((ch = in.read()) != -1){
            numberOfchar++;

            if(ch == ' ' || ch== '\n'){
                numberOfWord++;
            }

            if(ch=='\n'){
                numberOfLine++;
            }
        }

        System.out.println("Line = "+numberOfLine);
        System.out.println("Word = "+numberOfWord);
        System.out.println("Character = "+numberOfchar);
        
        in.close();

    }
}
