import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

public class A2 {
    public static void main(String[] args) throws Exception {
        
        Scanner sc = new Scanner(System.in);

        FileInputStream in = new FileInputStream("demo.txt");
        FileOutputStream out = new FileOutputStream("out.txt");

        System.out.println("Enter word 1 = ");
        String word1 = sc.nextLine();

        System.out.println("Enter word 2 = ");
        String word2 = sc.nextLine();

        int count = 0;
        String data = "";
        int ch;

        while((ch = in.read()) != -1){
            data+=(char)ch;
        }
        data=data.replaceAll(word1, word2);


        out.write(data.getBytes());
        out.close();
        in.close();
        System.out.println("Number of replacment = " + count);
    }
}
