import java.io.FileInputStream;
public class B1 {
    public static void main(String[] args) throws Exception {
        String FileName = args[0];

        FileInputStream in = new FileInputStream(FileName);

        int i = 0;
        int count = 0;

        while ((i = in.read()) != -1) {
            if (i== '5') {
                count++;
            }
        }

        System.out.println("Number of occurrences of digit 5 = " + count);

        in.close();
    }
}
