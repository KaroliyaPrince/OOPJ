import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

class Student {
    String name;
    int roll_no;
    String department;

    Student(String name, int roll_no, String department) {
        this.name = name;
        this.roll_no = roll_no;
        this.department = department;
    }

}

class FileReadWrite {
    Student[] fileRead(String filePath) throws Exception {

        FileInputStream in = new FileInputStream(filePath);
        Scanner sc_file = new Scanner(in);

        int numberOfRecords = 0;

        while (sc_file.hasNextLine()) {
            numberOfRecords++;
            sc_file.nextLine();
        }

        sc_file.close();
        in = new FileInputStream(filePath);
        sc_file = new Scanner(in);

        Student[] records = new Student[numberOfRecords];
        int numberOfAddRecord = 0;
        String record;
        String[] temp = new String[3];
        String name;
        int roll_no;
        String department;

        while (sc_file.hasNextLine()) {
            record = sc_file.nextLine();
            temp = record.split(",");
            name = temp[0];
            roll_no = Integer.parseInt(temp[1]);
            department = temp[2];
            records[numberOfAddRecord++] = new Student(name, roll_no, department);

        }
        return records;
    }

    void fileAdd(String filePath) throws Exception {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Name = ");
        String name = sc.nextLine();

        System.out.print("Enter roll_no = ");
        int roll_no = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter department = ");
        String department = sc.nextLine();

        String record = "\n"+name+","+roll_no+","+department;

        byte[] b = record.getBytes();

        FileOutputStream out = new FileOutputStream(filePath,true);
        out.write(b);
        out.close();
    }
}

public class C {
    public static void main(String[] args) throws Exception {

        FileReadWrite fileReadWrite = new FileReadWrite();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter file path = ");
        String filePath = sc.nextLine();

        while(true){
            System.out.println("<----Enter choice---->");
            System.out.println("1 for Add data in file");
            System.out.println("2 for get data from file");
            System.out.println("3 for Exit");
            int choice = sc.nextInt();

            switch(choice){
                case 1:{
                    fileReadWrite.fileAdd(filePath);
                    break;
                }

                case 2:{
                    Student[] records = fileReadWrite.fileRead(filePath);

                    for(int i=0 ; i<records.length;i++){
                        System.out.println();
                        System.out.println("<----Student "+(i+1)+" details---->");
                        System.out.println("Name = "+records[i].name);
                        System.out.println("Roll No. = "+records[i].roll_no);
                        System.out.println("Department = "+records[i].department);
                    }
                    break;
                }
                case 3:{
                    return;
                }
            }
        }
    }
}
