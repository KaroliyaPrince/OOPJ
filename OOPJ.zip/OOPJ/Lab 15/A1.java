import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

class Student {
    String name;
    int roll_no;
    String department;

    Student(String name, int roll_no, String department) {
        this.name = name;
        this.roll_no = roll_no;
        this.department = department;
    }
}

class FileReadWrite {

    void addDataInFile(String filePath) throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Name = ");
        String name = sc.nextLine();

        System.out.print("Enter roll_no = ");
        int roll_no = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter department = ");
        String department = sc.nextLine();

        String record = "\n" + name + "," + roll_no + "," + department;

        FileWriter fw = new FileWriter(filePath, true);
        BufferedWriter bw = new BufferedWriter(fw);

        bw.write(record);
        bw.close();
    }

    Student[] getDataFromFile(String filePath) throws Exception {

        FileReader fr = new FileReader(filePath);
        BufferedReader br = new BufferedReader(fr);

        String record;
        String[] temp = new String[3];
        Student[] studentRecords = new Student[100];
        int numberOfAddData = 0;

        while ((record = br.readLine()) != null) {
            temp = record.split(",");
            String name = temp[0];
            int roll_no = Integer.parseInt(temp[1]);
            String department = temp[2];

            studentRecords[numberOfAddData++] = new Student(name, roll_no, department);
        }

        fr.close();
        br.close();
        return studentRecords;
    }
}

public class A1 {
    public static void main(String[] args) throws Exception {

        FileReadWrite fileReadWrite = new FileReadWrite();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter file path = ");
        String filePath = sc.nextLine();

        while (true) {
            System.out.println("<----Enter choice---->");
            System.out.println("1 for Add data in file");
            System.out.println("2 for get data from file");
            System.out.println("3 for Exit");
            int choice = sc.nextInt();

            switch (choice) {
                case 1: {
                    fileReadWrite.addDataInFile(filePath);
                    break;
                }

                case 2: {
                    Student[] records = fileReadWrite.getDataFromFile(filePath);

                    for (int i = 0; i < records.length; i++) {
                        if (records[i] != null) {
                            System.out.println();
                            System.out.println("<----Student " + (i + 1) + " details---->");
                            System.out.println("Name = " + records[i].name);
                            System.out.println("Roll No. = " + records[i].roll_no);
                            System.out.println("Department = " + records[i].department);
                        }
                    }
                    break;
                }
                case 3: {
                    return;
                }
            }
        }
    }
}
