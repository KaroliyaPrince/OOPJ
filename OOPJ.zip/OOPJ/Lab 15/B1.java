import java.io.File;

public class B1 {
    public static void main(String[] args){
        String fileName = args[0];

        File f = new File(fileName);

        if(f.isFile()){
            System.out.println("File Size = "+f.length());
        }
        else if(f.isDirectory()){
            String[] files = f.list();
            for(int i=0;i<files.length;i++){
                System.out.println(files[i]);
            }
        }
    }    
}
