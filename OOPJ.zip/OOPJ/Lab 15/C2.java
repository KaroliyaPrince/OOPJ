/*
    Write a program to demonstrate the use of ArrayList to store and display List of Student 
class with StudentID, StudentName, StudentRollNo and StudentSPI.
*/

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

class SortStudent implements Comparator<Student>{
    public int compare(Student o1, Student o2) {
        if(o1.StudentSPI == o2.StudentSPI){
            return 0;
        }
        else if(o1.StudentSPI < o2.StudentSPI){
            return 1;
        }

        return -1;
    }
}

class Student{
    int StudentID;
    String StudentName;
    int StudentRollNo;
    double StudentSPI;

    Student(int StudentID,String StudentName,int StudentRollNo,double StudentSPI){
        this.StudentID = StudentID;
        this.StudentName = StudentName;
        this.StudentRollNo = StudentRollNo;
        this.StudentSPI = StudentSPI;
    }
}

public class C2 {
    public static void main(String[] args){
        List<Student> studentList = new ArrayList<Student>();
        Scanner sc = new Scanner(System.in);

        while(true){
            System.out.println("<----Enter Choice---->");
            System.out.println("1 for insert student data");
            System.out.println("2 for display data");
            System.out.println("3 for sort data");
            System.out.println("4 for Exit");
            int choice = sc.nextInt();

            switch(choice){
                case 1:{
                    System.out.print("Enter Student Id = ");
                    int StudentID = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Student Name = ");
                    String StudentName = sc.nextLine();

                    System.out.print("Enter Student Roll no. = ");
                    int StudentRollNo = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Student SPI = ");
                    double StudentSPI = sc.nextDouble();

                    Student s = new Student(StudentID, StudentName, StudentRollNo, StudentSPI);
                    studentList.add(s);
                    break;
                }
                case 2:{

                    for(int i=0 ; i<studentList.size();i++){
                        System.out.println();
                        System.out.println("<----Student "+(i+1)+" Details---->");
                        System.out.println("Id = "+studentList.get(i).StudentID);
                        System.out.println("Name = "+studentList.get(i).StudentName);
                        System.out.println("Roll no. = "+studentList.get(i).StudentRollNo);
                        System.out.println("SPI = "+studentList.get(i).StudentSPI);
                    }
                    break;
                }

                case 3:{
                    Collections.sort(studentList,new SortStudent());
                    break;
                }

                case 4:{
                    return;
                }
            }
        }
    }    
}
