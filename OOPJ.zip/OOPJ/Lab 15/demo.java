
import java.util.ArrayList;
import java.util.List;

public class demo {
    public static void main(String[] args) {
        List<> l1=new ArrayList();
        l1.add("Sahil");
        l1.add("Prince");


    }
}
