public class L2_A_2 {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
