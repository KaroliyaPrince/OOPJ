
import java.util.Scanner;

public class L2_A_3 {
    public static void main(String[] args) {
        // System.out.println("Command line "+args[0]);
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Number");
        int a=sc.nextInt();
        System.out.println("Number is = "+a);
    }
}
