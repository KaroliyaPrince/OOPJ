import java.util.Scanner;

public class L2_B_5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter value in meter: ");
        float meter=sc.nextFloat();
        System.out.println("Feets are "+meter*3.280);
    }
}
