import java.util.Scanner;

public class L2_C_6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Character");
        String ch = sc.nextLine();

        if (ch.equals("a") || ch.equals("e") || ch.equals("i") || ch.equals("o") 
            || ch.equals("u") ||ch.equals("A") || ch.equals("E") || ch.equals("I") 
            || ch.equals("O") || ch.equals("U"))
            System.out.println("Vowel");
        else
            System.out.println("Consonant");
    }
}
