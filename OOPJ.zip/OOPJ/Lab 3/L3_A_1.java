public class L3_A_1{
    public static void main(String[] args) {
        System.out.println("10 + 20 * 30 = "+(10+20*30));
        System.out.println("100 / 10 * 100 = "+(100/10*100));
        System.out.println("5 * 4 / 4 % 3 = "+(5*4/4%3));
        System.out.println("100 + 200 / 10 - 3 * 10 = "+(100+200/10-3*10));
    }
}