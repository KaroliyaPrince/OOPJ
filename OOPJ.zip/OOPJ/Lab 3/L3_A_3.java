import java.util.Scanner;

public class L3_A_3 {
    public static void main(String[] args)
	{
		Scanner	sc=new Scanner(System.in);
		System.out.print("Enter Length ");
		double a=sc.nextDouble();
		System.out.print("Enter Width ");
		double b=sc.nextDouble();
		double c=a*b;
		System.out.print("Answer = "+c);
	}
}
