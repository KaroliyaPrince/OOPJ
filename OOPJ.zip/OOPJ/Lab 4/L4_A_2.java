import java.util.Scanner;

public class L4_A_2 {
    public static void main(String[] args)
	{
		Scanner	sc=new Scanner(System.in);
		System.out.println("Enter Number ");
		int a=sc.nextInt();
		if(a%2==0)
			System.out.println("Even Number");
		else 
			System.out.println("Odd Number");
	}
}
