import java.util.Scanner;
public class L5_A_1 {
    public static void main(String[] args)
	{
		Scanner	sc=new Scanner(System.in);
		System.out.println("Enter Number of Element in Array");
		int a=sc.nextInt();
		int[] arr=new int[a];
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			System.out.print("Enter Number");
			arr[i]=sc.nextInt();
			sum+=arr[i];
		}
		System.out.println("Sum is = "+sum);
	}
}
