import java.util.Scanner;

public class L5_B_4 {
    public static void main(String[] args) {
        Scanner	sc=new Scanner(System.in);
		System.out.println("Enter Number of Element in Array");
		int n=sc.nextInt();
		int[] arr=new int[n];
        int[] arr1=new int[n];
		for(int i=0;i<arr.length;i++){
            System.out.println("Enter Number");
			arr[i]=sc.nextInt();
            arr1[i]=arr[i];
		}
        System.out.println("First Array");
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.print("Second Array");
        for(int i=0;i<arr1.length;i++){
            System.out.print(arr1[i]+" ");
        }
    }
}
