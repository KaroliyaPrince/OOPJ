import java.util.Scanner;
public class L5_C_7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter size:");
        int n = sc.nextInt();
        int[] nums = new int[n];

        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }

        System.out.println("Enter Pivot(It should be between 0 and nums.length):");
        int pivot = sc.nextInt();

        L5_C_7 obj=new L5_C_7();
        nums=obj.rotate(nums,pivot);

        System.out.println("Rotatated Array");
        for(int i=0;i<nums.length;i++){
            System.out.print(nums[i]+",");
        }
        
        System.out.println("\nEnter Target:");
        int target = sc.nextInt();

        int index=obj.search(nums,target);

        if(index==-1){
            System.out.println("Element not Found");
        }else{
            System.out.println("Element Found at "+index);
        }
    }
    int[] rotate(int[] nums,int pivot){
        int[] rotated=new int[nums.length];
        int j=0;
        for(int i=pivot;i<nums.length;i++){   
            rotated[j++]=nums[i];
        }
        for(int i=0;i<pivot;i++){
            rotated[j++]=nums[i];
        }
        return rotated;
    }
    int search(int[] nums,int target){
        for(int i=0;i<nums.length;i++){
            if(nums[i]==target){
                return i;
            }
        }
        return -1;
    }
}
