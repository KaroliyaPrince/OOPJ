class Student {
    String name;
    int roll_no;
    double SPI;
    String course;

    public void setStudent(String name, int roll_no, double SPI, String course) {
        this.name = name;
        this.roll_no = roll_no;
        this.SPI = SPI;
        this.course = course;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Roll No: " + roll_no);
        System.out.println("SPI: " + SPI);
        System.out.println("Course: " + course);
    }
}

public class L6_A_1 {
    public static void main(String[] args) {

        Student s1 = new Student();
        Student s2 = new Student();
        Student s3 = new Student();

        s1.setStudent("Darshan", 1, 8.5, "Computer Engineering");
        s2.setStudent("Raj", 2, 9.1, "Information Technology");
        s3.setStudent("Simran", 3, 7.9, "Electronics");

        System.out.println("Student 1");
        s1.display();

        System.out.println("Student 2");
        s2.display();

        System.out.println("Student 3");
        s3.display();
    }
}
