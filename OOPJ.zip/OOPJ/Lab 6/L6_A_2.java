class Cube {
    double height;
    double width;
    double depth;

    public void setCube(double height, double width, double depth) {
        this.height = height;
        this.width = width;
        this.depth = depth;
    }

    public void getCube() {
        System.out.println("Height: " + height);
        System.out.println("Width: " + width);
        System.out.println("Depth: " + depth);
    }

    public double volume() {
        return height * width * depth;
    }
}

public class L6_A_2 {
    public static void main(String[] args) {
        Cube c1 = new Cube();
        Cube c2 = new Cube();

        c1.setCube(3.0, 4.0, 5.0);
        c2.setCube(2.5, 6.0, 3.5);

        System.out.println("Cube 1:");
        c1.getCube();
        System.out.println("Volume: " + c1.volume());

        System.out.println("Cube 2:");
        c2.getCube();
        System.out.println("Volume: " + c2.volume());
    }
}
