class Account {
    int accNum;
    String accType;
    double balance;

    public void setAccount(int accNum, String accType, double balance) {
        this.accNum = accNum;
        this.accType = accType;
        this.balance = balance;
    }

    public void getAccount() {
        System.out.println("Account Number: " + accNum);
        System.out.println("Account Type: " + accType);
        System.out.println("Balance: " + balance);
    }
}

public class L6_A_3 {
    public static void main(String[] args) {
        Account a1 = new Account();
        Account a2 = new Account();
        Account a3 = new Account();

        a1.setAccount(101, "Savings", 15000.50);
        a2.setAccount(102, "Current", 23000.75);
        a3.setAccount(103, "Salary", 18000.00);

        System.out.println("Account 1");
        a1.getAccount();

        System.out.println("Account 2");
        a2.getAccount();

        System.out.println("Account 3");
        a3.getAccount();
    }
}

