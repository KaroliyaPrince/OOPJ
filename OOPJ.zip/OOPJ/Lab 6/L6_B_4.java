import java.util.Scanner;

class A {
    int arr[] = new int[5];

    public void setArray() {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            arr[i] = sc.nextInt();
        }
    }

    public void sortArray() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5 - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        System.out.print("Sorted Array: ");
        for (int i = 0; i < 5; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public void searchArray(int key) {
        boolean found = false;
        for (int i = 0; i < 5; i++) {
            if (arr[i] == key) {
                System.out.println(key + " found at index " + i);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println(key + " not found in array");
        }
    }

    public void sumArray() {
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += arr[i];
        }
        System.out.println("Sum = " + sum);
    }

    public void avgArray() {
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += arr[i];
        }
        System.out.println("Average = " + (sum / 5.0));
    }
}

public class L6_B_4 {
    public static void main(String[] args) {
        A obj = new A();

        System.out.println("Enter 5 array elements:");
        obj.setArray();

        obj.sortArray();
        obj.searchArray(10);
        obj.sumArray();
        obj.avgArray();
    }
}
