class Employee {
    String name;
    String jobTitle;
    double salary;

    public Employee(String name, String jobTitle, double salary) {
        this.name = name;
        this.jobTitle = jobTitle;
        this.salary = salary;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Job Title: " + jobTitle);
        System.out.println("Salary: " + salary);
    }

    public void updateSalary(double percent) {
        salary += salary * percent / 100;
        System.out.println("Salary updated by " + percent + "%");
    }
}

public class L6_B_5 {
    public static void main(String[] args) {
        Employee e1 = new Employee("Sahil", "Software Engineer", 50000);
        Employee e2 = new Employee("Yash", "Manager", 75000);

        System.out.println("Before Salary Update:");
        e1.display();
        System.out.println();
        e2.display();

        System.out.println("Updating Salary by 10%");
        e1.updateSalary(10);
        e2.updateSalary(10);

        System.out.println("After Salary Update:");
        e1.display();
        System.out.println();
        e2.display();
    }
}
