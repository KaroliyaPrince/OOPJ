class Circle {
    double radius;

    public void setRadius(double rad) {
        radius = rad;
    }

    public double area() {
        return Math.PI * radius * radius;
    }
}

public class L7_A_1 {
    public static void main(String[] args) {
        Circle c = new Circle();

        c.setRadius(5.0);
        System.out.println("Radius: " + c.radius);
        System.out.println("Area of Circle: " + c.area());
    }
}
