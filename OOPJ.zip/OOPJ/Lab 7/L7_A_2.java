import java.util.Scanner;

public class L7_A_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter hour (1-12): ");
        int hour = sc.nextInt();

        System.out.print("Enter minutes (0-59): ");
        int minute = sc.nextInt();

        double hourAngle = (hour % 12 + minute / 60.0) * 30;
        double minuteAngle = minute * 6;

        double angle = Math.abs(hourAngle - minuteAngle);

        if (angle > 180) {
            angle = 360 - angle;
        }

        System.out.println("Angle between hour and minute hands: " + angle + " degrees");
    }
}
