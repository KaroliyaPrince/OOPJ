import java.util.Scanner;
class Sentence{
    int vowelA=0,vowelE=0,vowelI=0,vowelO=0,vowelU=0;


    public void checkMethod(){
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("Enter quit for Quit or Enter Sentence");
            String sentence=sc.next(); 
            if(sentence.equals("quit")){
                break;
            }
            for(int i=0;i<sentence.length();i++){
                char c=sentence.charAt(i);
                if(c==('a')||c==('A')){
                    vowelA++;
                }
                else if (c==('e')||c==('E')){
                    vowelE++;
                }
                else if (c==('i')||c==('I')){
                    vowelI++;
                }
                else if (c==('o')||c==('O')){
                    vowelO++;
                }
                else if (c==('u')||c==('U')){
                    vowelU++;
                }
            }
        }
        System.out.println("Vowel A: "+vowelA);
        System.out.println("Vowel E: "+vowelE);
        System.out.println("Vowel I: "+vowelI);
        System.out.println("Vowel O: "+vowelO);
        System.out.println("Vowel U: "+vowelU);
    }
}

public class L7_B_3 {
    public static void main(String[] args){
        Sentence str =new Sentence();
        str.checkMethod();
    }
}
