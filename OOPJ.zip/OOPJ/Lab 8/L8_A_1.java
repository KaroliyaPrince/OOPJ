import java.util.Scanner;

class Time {
    int hours;
    int minutes;
    int seconds;
    Time(){}

    Time(int h, int m, int s) {
        this.hours = h;
        this.minutes = m;
        this.seconds = s;
    }

    void displayTime() {
        System.out.printf("%02d:%02d:%02d\n", hours, minutes, seconds);
    }

    Time add(Time t1,Time t2) {
        Time result = new Time();
        result.seconds = t1.seconds + t2.seconds;
        result.minutes = t1.minutes + t2.minutes + result.seconds / 60;
        result.seconds = result.seconds % 60;
        result.hours = t1.hours + t2.hours + result.minutes / 60;
        result.minutes = result.minutes % 60;
        return result;
    }
}

public class L8_A_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.println("Enter first time (hours minutes seconds):");
        int h1 = sc.nextInt();
        int m1 = sc.nextInt();
        int s1 = sc.nextInt();
        Time t1 = new Time(h1, m1, s1);
        
        System.out.println("Enter second time (hours minutes seconds):");
        h1 = sc.nextInt();
        m1 = sc.nextInt();
        s1 = sc.nextInt();
        Time t2 = new Time(h1, m1, s1);

        Time sum = new Time();
        sum=t1.add(t1,t2);

        System.out.print("Sum of times: ");
        sum.displayTime();
    }
}
