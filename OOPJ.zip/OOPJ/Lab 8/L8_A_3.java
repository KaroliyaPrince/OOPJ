class BankAccount {
    int accountNo;
    double balance;
    static String bankName;
    static double interestRate;

    BankAccount(int accountNo, double balance) {
        this.accountNo = accountNo;
        this.balance = balance;
    }

    static void setBankInfo(String name, double rate) {
        bankName = name;
        interestRate = rate;
    }

    void display() {
        System.out.println("Account No: " + accountNo);
        System.out.println("Balance: " + balance);
        System.out.println("Bank Name: " + bankName);
        System.out.println("Interest Rate: " + interestRate + "%");
    }
}

public class L8_A_3 {
    public static void main(String[] args) {
        BankAccount.setBankInfo("SBI Bank", 6.5);

        BankAccount b1 = new BankAccount(101, 15000);
        BankAccount b2 = new BankAccount(102, 23000);
        BankAccount b3 = new BankAccount(103, 18000);

        b1.display();
        b2.display();
        b3.display();
    }
}
