class Area {
    static final double PI = 3.14159;

    double circleArea(double radius) {
        return PI * radius * radius;
    }
}

public class L8_B_4 {
    public static void main(String[] args) {
        Area a = new Area();
        double area = a.circleArea(10);
        System.out.println("Area of circle: " + area);
    }
}
