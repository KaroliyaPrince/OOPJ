class House {
    private String address;
    private int numberOfRooms;
    private double area;

    House(String address, int numberOfRooms, double area) {
        this.address = address;
        this.numberOfRooms = numberOfRooms;
        this.area = area;
    }

    void getData() {
        System.out.println("Address: " + address);
        System.out.println("Rooms: " + numberOfRooms);
        System.out.println("Area: " + area);
    }

    double calculatePrice(double pricePerSqM) {
        return area * pricePerSqM;
    }
}

public class L8_C_5 {
    public static void main(String[] args) {
        House h = new House("123 Jail Chowk", 4, 120.5);

        h.getData();

        System.out.println("Price: " + h.calculatePrice(1500));
    }
}
