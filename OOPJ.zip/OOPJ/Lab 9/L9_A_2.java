
import java.util.Scanner;

class Employee {

    String name;
    String work;
    int salary;

    public Employee(String name, String work, int salary) {
        this.name = name;
        this.work = work;
        this.salary = salary;
    }

    public void work() {
        System.out.println("Employee name=" + name);
        System.out.println("Employee work=" + work);
    }

    public void getSalary() {
        System.out.println("Employee work=" + work);

    }
}

class HRManager extends Employee {

    public HRManager(String name, String work, int salary) {
        super(name, work, salary);
    }

    @Override
    public void work() {
        System.out.println("HR Manager name" + name);
        System.out.println("HR Manager work" + work);
    }

    public Employee addEmployee() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ente employee name");
        String emp_name = sc.next();
        System.out.println("Ente employee work");
        String emp_work = sc.next();
        System.out.println("Ente employee salaary");
        int emp_salary = sc.nextInt();
        return new Employee(emp_name, emp_work, emp_salary);
    }
}

public class L9_A_2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ente hrmanager name");
        String name = sc.next();
        System.out.println("Ente hrmanager work");
        String work = sc.next();
        System.out.println("Ente hrmanager salaary");
        int salary = sc.nextInt();

        HRManager hr = new HRManager(name, work, salary);
        Employee emp = hr.addEmployee();

        System.out.println("HR Manager details");
        hr.work();
        hr.getSalary();

        System.out.println("Employee details");
        emp.work();
        emp.getSalary();
    }
}
